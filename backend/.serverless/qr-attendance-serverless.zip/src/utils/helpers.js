// Tính khoảng cách giữa 2 tọa độ GPS (Trả về số mét)
function getDistanceInMeters(lat1, lon1, lat2, lon2) {
    const R = 6371000; // Bán kính Trái Đất tính bằng mét
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    
    const a = 
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c; // Khoảng cách bằng mét
}

// Hàm tạo mã ngẫu nhiên 6 ký tự cho mã QR (giống OTP)
function generateRandomToken() {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
}

module.exports = { getDistanceInMeters, generateRandomToken };